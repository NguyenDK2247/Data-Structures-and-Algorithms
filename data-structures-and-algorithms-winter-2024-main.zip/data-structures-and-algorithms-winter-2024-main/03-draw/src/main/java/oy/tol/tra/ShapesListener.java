package oy.tol.tra;

public interface ShapesListener {
    void shapesChanged();
    void exceptionHappened(String reason);
}
