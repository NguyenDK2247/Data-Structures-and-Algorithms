package oy.tol.tra;

public class ShapeException extends Exception {
    public ShapeException(String reason) {
        super(reason);
    }
}
