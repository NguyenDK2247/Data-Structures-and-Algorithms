Follow these steps to clone your personal repository to your own computer.

* In the terminal (command prompt), navigate to where you want the repository cloned. You should make a new directory for it and name it so that the path name does not contain empty spaces or any exotic characters.
* Go to your personal repository in gitlab
* In the left side-bar find `repository` and select `files`.
* In the top-left, press the button `clone`.
* It will give you two addresses. Copy the one under `clone with ssh`.
* Go back to the terminal (command prompt).
* Typ in git clone and the copied address:
```clone
git clone <paste the copied address>
```
* If password has been given, it will ask for it at this point.
* Onec cloning is done, you can check with `dir` command that the repository is in the directory.
