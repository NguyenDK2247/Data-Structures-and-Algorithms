package oy.tol.tra;

public class LinkedListAllocationException extends RuntimeException {
   public LinkedListAllocationException(String message) {
      super(message);
   }
}
