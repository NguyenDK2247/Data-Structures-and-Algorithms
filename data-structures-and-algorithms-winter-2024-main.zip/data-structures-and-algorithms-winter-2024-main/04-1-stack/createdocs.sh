javadoc src/main/java/oy/tol/tra/*.java -d doc

