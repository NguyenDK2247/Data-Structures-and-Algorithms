package oy.tol.tra;

public class HashBrailleTable extends BrailleTable {

   // TODO: Implement this without using 67-phonebook hash table nor Java hash tables.
   // Make sure you understand the required limited ways to implement this task!
   // Ask teachers to be sure!

   @Override
   protected void initializeTable() {
   }

   @Override
   protected void addToTable(Character character, Character brailleSymbol) {
   }

   @Override
   public Character lookupBrailleSymbol(Character forCharacter) {
      return null;
   }

   @Override
   public Character lookupCharacter(Character forBrailleSymbol) {
      return null;
   }

}
