package oy.tol.tra;

public class InvalidBrailleFileFormatException extends Exception {
   public InvalidBrailleFileFormatException(String reason) {
      super(reason);
   } 
}
