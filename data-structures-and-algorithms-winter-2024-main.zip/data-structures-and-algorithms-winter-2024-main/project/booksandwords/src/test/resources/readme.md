Unzip the testfiles.zip to this directory.

The test files are used in testing the implementation.

Tests fail if the zip file is not unzipped.

Note that you MUST NOT edit these files in any way!
